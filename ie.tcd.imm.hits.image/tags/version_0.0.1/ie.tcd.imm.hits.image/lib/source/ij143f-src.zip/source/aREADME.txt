The ant utility (http://ant.apache.org/) will compile and run ImageJ using 
the build file (build.xml) in this directory. There is a version of ant at   

    http://rsb.info.nih.gov/ij/download/tools/ant/ant.zip
    
set up to use the JVM distributed with the Windows version of ImageJ.
The README included in the ZIP archive has more information.
